/* global chrome */

console.info("%cRunning JIRA STICKY HEADER Chrome extension", "font-weight: bold; color: #0088ff; background-color: #e8f8ff;");
console.info(`%cExtension version: ${chrome.runtime.getManifest().version}`, "color: #0088ff; background-color: #e8f8ff;");

let IS_DEV_MODE = !('update_url' in chrome.runtime.getManifest());
const ISSUE_HEADER_CLASS = 'issue-header-content';
let issueHeaderObserver;

if (IS_DEV_MODE) {
    console.info("%cRunning in developer mode, enabling debugging",
            "color: #a02820; background-color: #ffe8d8;");
}

document.addEventListener('readystatechange', event => {
  if (issueHeaderObserver) {
    issueHeaderObserver.disconnect();
  }
  if (event.target.readyState === 'complete') {
    checkForIssueHeader();
  }
});

function checkForIssueHeader() {
  const jiraEl = document.getElementById('jira');
  if (!jiraEl) {
    console.log('This does not seem to be a Jira page, bailing...');
    return;
  }

  /*
   * Set up mutation observer to spot when an issue header is added to page
   */
  issueHeaderObserver = new MutationObserver((mutations) => {
    for (let m of mutations) {
      // console.log(m);
      if (m.addedNodes.length === 1 && m.target.className === 'issue-container') {
        console.log('An issue header was added!');
        makeHeaderSticky(m.target.getElementsByClassName(ISSUE_HEADER_CLASS)[0]);
      }
    }
  });
  let conf = {
    attributes: false,
    childList: true,
    characterData: false,
    subtree: true,
  };
  issueHeaderObserver.observe(jiraEl, conf);

  /*
   * Check if a header is already existing.
   */
  const el = document.getElementsByClassName(ISSUE_HEADER_CLASS);
  if (el.length === 0) {
    return;
  }
  console.info("Found issue header, making it sticky!"); 
  console.assert(el.length === 1, "More than one issue header found: " + el.length);
  makeHeaderSticky(el[0]);
}

function makeHeaderSticky(el) {
  const stalker = el.parentElement;
  console.assert(stalker.id === "stalker", "Parent is not a stalker 😱");
  stalker.classList.add('sticky-issue-header');
  //stalker.style.position = 'sticky';
  // stalker.style.top = '0';
  // stalker.style.width = '100%';
  //stalker.style.zIndex = '1';  
  el.classList.add('custom-issue-header');
  el.style.zIndex = '3';
}
